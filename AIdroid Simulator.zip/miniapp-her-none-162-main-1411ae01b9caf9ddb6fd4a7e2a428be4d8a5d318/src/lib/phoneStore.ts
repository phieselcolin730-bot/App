'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface InstalledApp {
  id: string
  name: string
  icon: string
  developer: string
  category: string
  type: 'game' | 'app'
  launchType: string // e.g., 'roblox', 'calculator', etc.
}

interface PhoneStore {
  installedApps: InstalledApp[]
  installApp: (app: InstalledApp) => void
  uninstallApp: (appId: string) => void
  isAppInstalled: (appId: string) => boolean
  clearAllApps: () => void
}

export const usePhoneStore = create<PhoneStore>()(
  persist(
    (set, get) => ({
      installedApps: [
        // Pre-installed apps
        {
          id: 'tiktok',
          name: 'TikTok',
          icon: '🎵',
          developer: 'TikTok Ltd.',
          category: 'Entertainment',
          type: 'app',
          launchType: 'tiktok'
        },
        {
          id: 'netflix',
          name: 'Netflix',
          icon: '🎬',
          developer: 'Netflix, Inc.',
          category: 'Entertainment', 
          type: 'app',
          launchType: 'netflix'
        }
      ],

      installApp: (app) =>
        set((state) => ({
          installedApps: state.installedApps.some(installedApp => installedApp.id === app.id)
            ? state.installedApps
            : [...state.installedApps, app]
        })),

      uninstallApp: (appId) =>
        set((state) => ({
          installedApps: state.installedApps.filter(app => app.id !== appId)
        })),

      isAppInstalled: (appId) =>
        get().installedApps.some(app => app.id === appId),

      clearAllApps: () =>
        set({ installedApps: [] })
    }),
    {
      name: 'phone-storage',
      getStorage: () => (typeof window !== 'undefined' ? localStorage : undefined)
    }
  )
)