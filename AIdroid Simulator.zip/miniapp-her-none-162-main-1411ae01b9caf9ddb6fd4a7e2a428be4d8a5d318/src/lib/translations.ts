// Language translation system for AIdroid phone simulator
export interface TranslationKey {
  // Boot screen
  bootTitle: string
  bootSubtitle: string
  
  // Language selection
  selectLanguageTitle: string
  selectLanguageSubtitle: string
  searchLanguages: string
  
  // PIN setup
  pinSetupTitle: string
  pinSetupSubtitle: string
  pinConfirmTitle: string
  pinConfirmSubtitle: string
  pinMismatchError: string
  
  // Loading screen
  loadingMessages: string[]
  
  // Home screen
  welcomeTitle: string
  languageLabel: string
  
  // Settings
  settingsTitle: string
  networkTitle: string
  networkSubtitle: string
  connectToNetwork: string
  connected: string
  disconnected: string
  selectNetwork: string
  
  // Apps
  appNames: {
    whatsapp: string
    playstore: string
    camera: string
    gallery: string
    settings: string
    calendar: string
    music: string
    maps: string
    weather: string
    calculator: string
    contacts: string
    phone: string
    browser: string
    clock: string
    messages: string
  }
  
  // Network status
  networkRequired: string
  noNetworkAccess: string
  connectFirst: string
  
  // Battery
  batteryDead: string
  batteryCharging: string
  lowBattery: string
  
  // Calling
  calling: string
  comingSoon: string
  wantToGoBack: string
  
  // Emergency calls
  emergency: {
    police911: string
    whatIsEmergency: string
    thisIsFakeCall: string
    emergencyEnded: string
  }
  
  // WhatsApp responses
  autoResponses: string[]
  
  // WhatsApp maintenance
  whatsappMaintenance: {
    title: string
    message: string
    useContacts: string
    returnDate: string
    okButton: string
  }
  
  // Authentication system
  auth: {
    // Account creation
    createAccountTitle: string
    createAccountSubtitle: string
    emailLabel: string
    emailPlaceholder: string
    emailRequired: string
    emailInvalid: string
    emailValid: string
    continueButton: string
    accountInfo: string
    termsInfo: string
    
    // PIN authentication
    welcomeBack: string
    enterPin: string
    pinIncorrect: string
    attemptsLeft: string
    accountLocked: string
    tryAgainIn: string
    authSuccess: string
    securityLock: string
    unlockIn: string
    
    // PIN recovery
    forgotPin: string
    recoveryTitle: string
    recoverySubtitle: string
    sendCode: string
    sending: string
    codeSent: string
    checkEmail: string
    waitingForCode: string
    enterCode: string
    codeInstructions: string
    verifyCode: string
    codeInvalid: string
    codeIncorrect: string
    recoveryFailed: string
    recoveryError: string
    
    // PIN reset
    createNewPin: string
    confirmNewPin: string
    pinTooShort: string
    pinMismatch: string
    pinMatched: string
    resetPin: string
    resetSuccess: string
    resetComplete: string
    resetFailed: string
    redirecting: string
  }
  
  // Common
  back: string
  cancel: string
  ok: string
  yes: string
  no: string
  search: string
  install: string
  uninstall: string
  installed: string
}

export const translations: Record<string, TranslationKey> = {
  'English': {
    bootTitle: 'AIdroid',
    bootSubtitle: 'Powered by OharaAI',
    selectLanguageTitle: 'Select Language',
    selectLanguageSubtitle: 'Choose your preferred language',
    searchLanguages: 'Search languages...',
    pinSetupTitle: 'Set PIN',
    pinSetupSubtitle: 'Create a 4-digit PIN to secure your phone',
    pinConfirmTitle: 'Confirm PIN',
    pinConfirmSubtitle: 'Enter your PIN again to confirm',
    pinMismatchError: 'PINs do not match. Please try again.',
    loadingMessages: [
      'Initializing AIdroid system...',
      'Loading applications...',
      'Setting up security...',
      'Configuring network...',
      'Preparing interface...',
      'Almost ready...',
      'Welcome to AIdroid!'
    ],
    welcomeTitle: 'Welcome to AIdroid!',
    languageLabel: 'Language',
    settingsTitle: 'Settings',
    networkTitle: 'Network Settings',
    networkSubtitle: 'Manage your network connections',
    connectToNetwork: 'Connect to Network',
    connected: 'Connected',
    disconnected: 'Disconnected',
    selectNetwork: 'Select a network to connect',
    appNames: {
      whatsapp: 'WhatsApp',
      playstore: 'Play Store',
      camera: 'Camera',
      gallery: 'Gallery',
      settings: 'Settings',
      calendar: 'Calendar',
      music: 'Music',
      maps: 'Maps',
      weather: 'Weather',
      calculator: 'Calculator',
      contacts: 'Contacts',
      phone: 'Phone',
      browser: 'Browser',
      clock: 'Clock',
      messages: 'Messages'
    },
    networkRequired: 'Network Required',
    noNetworkAccess: 'No network access',
    connectFirst: 'Connect to a network first',
    batteryDead: 'Battery Dead',
    batteryCharging: 'Charging...',
    lowBattery: 'Low Battery',
    calling: 'Calling...',
    comingSoon: 'Coming Soon!',
    wantToGoBack: 'Want to go back?',
    emergency: {
      police911: 'Police 🚨',
      whatIsEmergency: '911 What is your Emergency?',
      thisIsFakeCall: 'This is a Fake Call',
      emergencyEnded: 'Emergency call ended'
    },
    autoResponses: [
      'Hey! Thanks for your message! 😊',
      'I\'m busy right now, but I\'ll get back to you soon!',
      'Thanks for texting! I\'ll reply when I can 👍',
      'Got your message! Talk to you later! 💬',
      'Hi there! I\'ll respond as soon as possible ✨'
    ],
    whatsappMaintenance: {
      title: 'WhatsApp Maintenance',
      message: 'Sorry, WhatsApp is in Development due to Fix Bugs. You can Use Contacts.',
      useContacts: 'WhatsApp will coming back in 30 Sep. 2025',
      returnDate: 'Expected Return: September 30, 2025',
      okButton: 'OK, Use Contacts'
    },
    auth: {
      // Account creation
      createAccountTitle: 'Create Account',
      createAccountSubtitle: 'Set up your AIdroid account with email',
      emailLabel: 'Email Address',
      emailPlaceholder: 'Enter your email',
      emailRequired: 'Email is required',
      emailInvalid: 'Please enter a valid email address',
      emailValid: 'Email looks good!',
      continueButton: 'Continue',
      accountInfo: 'Your email will be used for PIN recovery',
      termsInfo: 'By continuing, you agree to AIdroid terms',
      
      // PIN authentication
      welcomeBack: 'Welcome Back',
      enterPin: 'Enter your 4-digit PIN',
      pinIncorrect: 'Incorrect PIN',
      attemptsLeft: 'attempts left',
      accountLocked: 'Account locked due to too many attempts',
      tryAgainIn: 'Try again in',
      authSuccess: 'Authentication successful!',
      securityLock: 'Account temporarily locked for security',
      unlockIn: 'Unlock in',
      
      // PIN recovery
      forgotPin: 'Forgot?',
      recoveryTitle: 'Recover PIN',
      recoverySubtitle: 'We\'ll send a recovery code to {email}',
      sendCode: 'Send Recovery Code',
      sending: 'Sending...',
      codeSent: 'Code Sent!',
      checkEmail: 'Check your email: {email}',
      waitingForCode: 'Waiting for system to send code...',
      enterCode: 'Enter Recovery Code',
      codeInstructions: 'Enter the 6-digit code from your email',
      verifyCode: 'Verify Code',
      codeInvalid: 'Please enter a 6-digit code',
      codeIncorrect: 'Incorrect or expired code',
      recoveryFailed: 'Recovery failed. Please try again.',
      recoveryError: 'Error occurred during recovery',
      
      // PIN reset
      createNewPin: 'Create New PIN',
      confirmNewPin: 'Confirm New PIN',
      pinTooShort: 'PIN must be 4 digits',
      pinMismatch: 'PINs do not match',
      pinMatched: 'PINs match!',
      resetPin: 'Reset PIN',
      resetSuccess: 'PIN Reset Successfully!',
      resetComplete: 'Your PIN has been updated',
      resetFailed: 'Failed to reset PIN',
      redirecting: 'Redirecting to login...'
    },
    back: 'Back',
    cancel: 'Cancel',
    ok: 'OK',
    yes: 'Yes',
    no: 'No',
    search: 'Search',
    install: 'Install',
    uninstall: 'Uninstall',
    installed: 'Installed'
  },
  
  'Español': {
    bootTitle: 'AIdroid',
    bootSubtitle: 'Desarrollado por OharaAI',
    selectLanguageTitle: 'Seleccionar Idioma',
    selectLanguageSubtitle: 'Elige tu idioma preferido',
    searchLanguages: 'Buscar idiomas...',
    pinSetupTitle: 'Configurar PIN',
    pinSetupSubtitle: 'Crea un PIN de 4 dígitos para proteger tu teléfono',
    pinConfirmTitle: 'Confirmar PIN',
    pinConfirmSubtitle: 'Ingresa tu PIN nuevamente para confirmar',
    pinMismatchError: 'Los PINs no coinciden. Inténtalo de nuevo.',
    loadingMessages: [
      'Inicializando sistema AIdroid...',
      'Cargando aplicaciones...',
      'Configurando seguridad...',
      'Configurando red...',
      'Preparando interfaz...',
      'Casi listo...',
      '¡Bienvenido a AIdroid!'
    ],
    welcomeTitle: '¡Bienvenido a AIdroid!',
    languageLabel: 'Idioma',
    settingsTitle: 'Configuración',
    networkTitle: 'Configuración de Red',
    networkSubtitle: 'Gestiona tus conexiones de red',
    connectToNetwork: 'Conectar a la Red',
    connected: 'Conectado',
    disconnected: 'Desconectado',
    selectNetwork: 'Selecciona una red para conectar',
    appNames: {
      whatsapp: 'WhatsApp',
      playstore: 'Play Store',
      camera: 'Cámara',
      gallery: 'Galería',
      settings: 'Configuración',
      calendar: 'Calendario',
      music: 'Música',
      maps: 'Mapas',
      weather: 'Clima',
      calculator: 'Calculadora',
      contacts: 'Contactos',
      phone: 'Teléfono',
      browser: 'Navegador',
      clock: 'Reloj',
      messages: 'Mensajes'
    },
    networkRequired: 'Red Requerida',
    noNetworkAccess: 'Sin acceso a red',
    connectFirst: 'Conecta a una red primero',
    batteryDead: 'Batería Agotada',
    batteryCharging: 'Cargando...',
    lowBattery: 'Batería Baja',
    calling: 'Llamando...',
    comingSoon: '¡Próximamente!',
    wantToGoBack: '¿Quieres volver?',
    emergency: {
      police911: 'Policía 🚨',
      whatIsEmergency: '911 ¿Cuál es su Emergencia?',
      thisIsFakeCall: 'Esta es una Llamada Falsa',
      emergencyEnded: 'Llamada de emergencia finalizada'
    },
    autoResponses: [
      '¡Hola! ¡Gracias por tu mensaje! 😊',
      'Estoy ocupado ahora, ¡pero te responderé pronto!',
      '¡Gracias por escribir! Te responderé cuando pueda 👍',
      '¡Recibí tu mensaje! ¡Hablamos luego! 💬',
      '¡Hola! Responderé tan pronto como sea posible ✨'
    ],
    whatsappMaintenance: {
      title: 'Mantenimiento de WhatsApp',
      message: 'Lo siento, WhatsApp está en Desarrollo debido a la Corrección de Errores. Puedes Usar Contactos.',
      useContacts: 'WhatsApp volverá el 30 Sep. 2025',
      returnDate: 'Regreso Esperado: 30 de Septiembre de 2025',
      okButton: 'OK, Usar Contactos'
    },
    auth: {
      // Account creation
      createAccountTitle: 'Crear Cuenta',
      createAccountSubtitle: 'Configura tu cuenta AIdroid con email',
      emailLabel: 'Dirección de Email',
      emailPlaceholder: 'Ingresa tu email',
      emailRequired: 'Email es requerido',
      emailInvalid: 'Por favor ingresa un email válido',
      emailValid: '¡Email se ve bien!',
      continueButton: 'Continuar',
      accountInfo: 'Tu email será usado para recuperar PIN',
      termsInfo: 'Al continuar, aceptas los términos de AIdroid',
      
      // PIN authentication
      welcomeBack: 'Bienvenido de Vuelta',
      enterPin: 'Ingresa tu PIN de 4 dígitos',
      pinIncorrect: 'PIN incorrecto',
      attemptsLeft: 'intentos restantes',
      accountLocked: 'Cuenta bloqueada por muchos intentos',
      tryAgainIn: 'Intenta de nuevo en',
      authSuccess: '¡Autenticación exitosa!',
      securityLock: 'Cuenta temporalmente bloqueada por seguridad',
      unlockIn: 'Desbloquear en',
      
      // PIN recovery
      forgotPin: '¿Olvidó?',
      recoveryTitle: 'Recuperar PIN',
      recoverySubtitle: 'Enviaremos un código de recuperación a {email}',
      sendCode: 'Enviar Código de Recuperación',
      sending: 'Enviando...',
      codeSent: '¡Código Enviado!',
      checkEmail: 'Revisa tu email: {email}',
      waitingForCode: 'Esperando que el sistema envíe el código...',
      enterCode: 'Ingresa Código de Recuperación',
      codeInstructions: 'Ingresa el código de 6 dígitos de tu email',
      verifyCode: 'Verificar Código',
      codeInvalid: 'Por favor ingresa un código de 6 dígitos',
      codeIncorrect: 'Código incorrecto o expirado',
      recoveryFailed: 'Recuperación falló. Intenta de nuevo.',
      recoveryError: 'Error ocurrió durante recuperación',
      
      // PIN reset
      createNewPin: 'Crear Nuevo PIN',
      confirmNewPin: 'Confirmar Nuevo PIN',
      pinTooShort: 'PIN debe ser de 4 dígitos',
      pinMismatch: 'PINs no coinciden',
      pinMatched: '¡PINs coinciden!',
      resetPin: 'Restablecer PIN',
      resetSuccess: '¡PIN Restablecido Exitosamente!',
      resetComplete: 'Tu PIN ha sido actualizado',
      resetFailed: 'Falló al restablecer PIN',
      redirecting: 'Redirigiendo al login...'
    },
    back: 'Atrás',
    cancel: 'Cancelar',
    ok: 'OK',
    yes: 'Sí',
    no: 'No',
    search: 'Buscar',
    install: 'Instalar',
    uninstall: 'Desinstalar',
    installed: 'Instalado'
  },
  
  'Français': {
    bootTitle: 'AIdroid',
    bootSubtitle: 'Propulsé par OharaAI',
    selectLanguageTitle: 'Sélectionner la Langue',
    selectLanguageSubtitle: 'Choisissez votre langue préférée',
    searchLanguages: 'Rechercher des langues...',
    pinSetupTitle: 'Configurer le PIN',
    pinSetupSubtitle: 'Créez un PIN à 4 chiffres pour sécuriser votre téléphone',
    pinConfirmTitle: 'Confirmer le PIN',
    pinConfirmSubtitle: 'Entrez votre PIN à nouveau pour confirmer',
    pinMismatchError: 'Les PINs ne correspondent pas. Veuillez réessayer.',
    loadingMessages: [
      'Initialisation du système AIdroid...',
      'Chargement des applications...',
      'Configuration de la sécurité...',
      'Configuration du réseau...',
      'Préparation de l\'interface...',
      'Presque prêt...',
      'Bienvenue dans AIdroid!'
    ],
    welcomeTitle: 'Bienvenue dans AIdroid!',
    languageLabel: 'Langue',
    settingsTitle: 'Paramètres',
    networkTitle: 'Paramètres Réseau',
    networkSubtitle: 'Gérez vos connexions réseau',
    connectToNetwork: 'Se connecter au réseau',
    connected: 'Connecté',
    disconnected: 'Déconnecté',
    selectNetwork: 'Sélectionnez un réseau à connecter',
    appNames: {
      whatsapp: 'WhatsApp',
      playstore: 'Play Store',
      camera: 'Appareil Photo',
      gallery: 'Galerie',
      settings: 'Paramètres',
      calendar: 'Calendrier',
      music: 'Musique',
      maps: 'Cartes',
      weather: 'Météo',
      calculator: 'Calculatrice',
      contacts: 'Contacts',
      phone: 'Téléphone',
      browser: 'Navigateur',
      clock: 'Horloge',
      messages: 'Messages'
    },
    networkRequired: 'Réseau Requis',
    noNetworkAccess: 'Pas d\'accès réseau',
    connectFirst: 'Connectez-vous d\'abord à un réseau',
    batteryDead: 'Batterie Morte',
    batteryCharging: 'Chargement...',
    lowBattery: 'Batterie Faible',
    calling: 'Appel en cours...',
    comingSoon: 'Bientôt disponible!',
    wantToGoBack: 'Voulez-vous revenir?',
    emergency: {
      police911: 'Police 🚨',
      whatIsEmergency: '911 Quelle est votre Urgence?',
      thisIsFakeCall: 'C\'est un Faux Appel',
      emergencyEnded: 'Appel d\'urgence terminé'
    },
    autoResponses: [
      'Salut! Merci pour votre message! 😊',
      'Je suis occupé maintenant, mais je vous répondrai bientôt!',
      'Merci d\'avoir écrit! Je répondrai quand je pourrai 👍',
      'J\'ai reçu votre message! À bientôt! 💬',
      'Bonjour! Je répondrai dès que possible ✨'
    ],
    whatsappMaintenance: {
      title: 'Maintenance WhatsApp',
      message: 'Désolé, WhatsApp est en Développement à cause de la Correction de Bugs. Vous pouvez Utiliser Contacts.',
      useContacts: 'WhatsApp reviendra le 30 Sep. 2025',
      returnDate: 'Retour Prévu: 30 Septembre 2025',
      okButton: 'OK, Utiliser Contacts'
    },
    auth: {
      // Account creation
      createAccountTitle: 'Créer un Compte',
      createAccountSubtitle: 'Configurez votre compte AIdroid avec email',
      emailLabel: 'Adresse Email',
      emailPlaceholder: 'Entrez votre email',
      emailRequired: 'Email est requis',
      emailInvalid: 'Veuillez entrer un email valide',
      emailValid: 'Email semble bon!',
      continueButton: 'Continuer',
      accountInfo: 'Votre email sera utilisé pour récupérer le PIN',
      termsInfo: 'En continuant, vous acceptez les termes AIdroid',
      
      // PIN authentication
      welcomeBack: 'Content de vous revoir',
      enterPin: 'Entrez votre PIN à 4 chiffres',
      pinIncorrect: 'PIN incorrect',
      attemptsLeft: 'tentatives restantes',
      accountLocked: 'Compte verrouillé à cause de trop de tentatives',
      tryAgainIn: 'Réessayez dans',
      authSuccess: 'Authentification réussie!',
      securityLock: 'Compte temporairement verrouillé pour sécurité',
      unlockIn: 'Déverrouiller dans',
      
      // PIN recovery
      forgotPin: 'Oublié?',
      recoveryTitle: 'Récupérer PIN',
      recoverySubtitle: 'Nous enverrons un code de récupération à {email}',
      sendCode: 'Envoyer Code de Récupération',
      sending: 'Envoi...',
      codeSent: 'Code Envoyé!',
      checkEmail: 'Vérifiez votre email: {email}',
      waitingForCode: 'En attente du système pour envoyer le code...',
      enterCode: 'Entrez le Code de Récupération',
      codeInstructions: 'Entrez le code à 6 chiffres de votre email',
      verifyCode: 'Vérifier le Code',
      codeInvalid: 'Veuillez entrer un code à 6 chiffres',
      codeIncorrect: 'Code incorrect ou expiré',
      recoveryFailed: 'Récupération échouée. Réessayez.',
      recoveryError: 'Erreur lors de la récupération',
      
      // PIN reset
      createNewPin: 'Créer Nouveau PIN',
      confirmNewPin: 'Confirmer Nouveau PIN',
      pinTooShort: 'PIN doit être de 4 chiffres',
      pinMismatch: 'PINs ne correspondent pas',
      pinMatched: 'PINs correspondent!',
      resetPin: 'Réinitialiser PIN',
      resetSuccess: 'PIN Réinitialisé avec Succès!',
      resetComplete: 'Votre PIN a été mis à jour',
      resetFailed: 'Échec de réinitialisation du PIN',
      redirecting: 'Redirection vers connexion...'
    },
    back: 'Retour',
    cancel: 'Annuler',
    ok: 'OK',
    yes: 'Oui',
    no: 'Non',
    search: 'Rechercher',
    install: 'Installer',
    uninstall: 'Désinstaller',
    installed: 'Installé'
  },
  
  'Deutsch': {
    bootTitle: 'AIdroid',
    bootSubtitle: 'Betrieben von OharaAI',
    selectLanguageTitle: 'Sprache auswählen',
    selectLanguageSubtitle: 'Wählen Sie Ihre bevorzugte Sprache',
    searchLanguages: 'Sprachen suchen...',
    pinSetupTitle: 'PIN einrichten',
    pinSetupSubtitle: 'Erstellen Sie eine 4-stellige PIN zur Sicherung Ihres Telefons',
    pinConfirmTitle: 'PIN bestätigen',
    pinConfirmSubtitle: 'Geben Sie Ihre PIN erneut ein, um zu bestätigen',
    pinMismatchError: 'PINs stimmen nicht überein. Bitte versuchen Sie es erneut.',
    loadingMessages: [
      'AIdroid-System wird initialisiert...',
      'Anwendungen werden geladen...',
      'Sicherheit wird eingerichtet...',
      'Netzwerk wird konfiguriert...',
      'Benutzeroberfläche wird vorbereitet...',
      'Fast bereit...',
      'Willkommen bei AIdroid!'
    ],
    welcomeTitle: 'Willkommen bei AIdroid!',
    languageLabel: 'Sprache',
    settingsTitle: 'Einstellungen',
    networkTitle: 'Netzwerkeinstellungen',
    networkSubtitle: 'Verwalten Sie Ihre Netzwerkverbindungen',
    connectToNetwork: 'Mit Netzwerk verbinden',
    connected: 'Verbunden',
    disconnected: 'Getrennt',
    selectNetwork: 'Wählen Sie ein Netzwerk zum Verbinden',
    appNames: {
      whatsapp: 'WhatsApp',
      playstore: 'Play Store',
      camera: 'Kamera',
      gallery: 'Galerie',
      settings: 'Einstellungen',
      calendar: 'Kalender',
      music: 'Musik',
      maps: 'Karten',
      weather: 'Wetter',
      calculator: 'Rechner',
      contacts: 'Kontakte',
      phone: 'Telefon',
      browser: 'Browser',
      clock: 'Uhr',
      messages: 'Nachrichten'
    },
    networkRequired: 'Netzwerk erforderlich',
    noNetworkAccess: 'Kein Netzwerkzugang',
    connectFirst: 'Verbinden Sie sich zuerst mit einem Netzwerk',
    batteryDead: 'Batterie Leer',
    batteryCharging: 'Lädt...',
    lowBattery: 'Schwache Batterie',
    calling: 'Anrufen...',
    comingSoon: 'Bald verfügbar!',
    wantToGoBack: 'Möchten Sie zurückgehen?',
    emergency: {
      police911: 'Polizei 🚨',
      whatIsEmergency: '911 Was ist Ihr Notfall?',
      thisIsFakeCall: 'Das ist ein Falscher Anruf',
      emergencyEnded: 'Notruf beendet'
    },
    autoResponses: [
      'Hallo! Danke für Ihre Nachricht! 😊',
      'Ich bin gerade beschäftigt, aber ich werde Ihnen bald antworten!',
      'Danke fürs Schreiben! Ich antworte, wenn ich kann 👍',
      'Habe Ihre Nachricht erhalten! Bis später! 💬',
      'Hallo! Ich werde so schnell wie möglich antworten ✨'
    ],
    whatsappMaintenance: {
      title: 'WhatsApp Wartung',
      message: 'Entschuldigung, WhatsApp ist in Entwicklung wegen der Fehlerbehebung. Sie können Kontakte verwenden.',
      useContacts: 'WhatsApp wird am 30. Sep. 2025 zurückkehren',
      returnDate: 'Erwartete Rückkehr: 30. September 2025',
      okButton: 'OK, Kontakte verwenden'
    },
    auth: {
      // Account creation
      createAccountTitle: 'Konto Erstellen',
      createAccountSubtitle: 'Richten Sie Ihr AIdroid-Konto mit E-Mail ein',
      emailLabel: 'E-Mail-Adresse',
      emailPlaceholder: 'Geben Sie Ihre E-Mail ein',
      emailRequired: 'E-Mail ist erforderlich',
      emailInvalid: 'Bitte geben Sie eine gültige E-Mail-Adresse ein',
      emailValid: 'E-Mail sieht gut aus!',
      continueButton: 'Weiter',
      accountInfo: 'Ihre E-Mail wird für PIN-Wiederherstellung verwendet',
      termsInfo: 'Durch Fortfahren stimmen Sie den AIdroid-Bedingungen zu',
      
      // PIN authentication
      welcomeBack: 'Willkommen zurück',
      enterPin: 'Geben Sie Ihre 4-stellige PIN ein',
      pinIncorrect: 'Falsche PIN',
      attemptsLeft: 'Versuche übrig',
      accountLocked: 'Konto wegen zu vieler Versuche gesperrt',
      tryAgainIn: 'Versuchen Sie es erneut in',
      authSuccess: 'Authentifizierung erfolgreich!',
      securityLock: 'Konto vorübergehend zur Sicherheit gesperrt',
      unlockIn: 'Entsperren in',
      
      // PIN recovery
      forgotPin: 'Vergessen?',
      recoveryTitle: 'PIN Wiederherstellen',
      recoverySubtitle: 'Wir senden einen Wiederherstellungscode an {email}',
      sendCode: 'Wiederherstellungscode Senden',
      sending: 'Wird gesendet...',
      codeSent: 'Code Gesendet!',
      checkEmail: 'Überprüfen Sie Ihre E-Mail: {email}',
      waitingForCode: 'Warten auf System zum Senden des Codes...',
      enterCode: 'Wiederherstellungscode Eingeben',
      codeInstructions: 'Geben Sie den 6-stelligen Code aus Ihrer E-Mail ein',
      verifyCode: 'Code Verifizieren',
      codeInvalid: 'Bitte geben Sie einen 6-stelligen Code ein',
      codeIncorrect: 'Falscher oder abgelaufener Code',
      recoveryFailed: 'Wiederherstellung fehlgeschlagen. Bitte erneut versuchen.',
      recoveryError: 'Fehler bei der Wiederherstellung aufgetreten',
      
      // PIN reset
      createNewPin: 'Neue PIN Erstellen',
      confirmNewPin: 'Neue PIN Bestätigen',
      pinTooShort: 'PIN muss 4 Stellen haben',
      pinMismatch: 'PINs stimmen nicht überein',
      pinMatched: 'PINs stimmen überein!',
      resetPin: 'PIN Zurücksetzen',
      resetSuccess: 'PIN Erfolgreich Zurückgesetzt!',
      resetComplete: 'Ihre PIN wurde aktualisiert',
      resetFailed: 'PIN-Reset fehlgeschlagen',
      redirecting: 'Weiterleitung zum Login...'
    },
    back: 'Zurück',
    cancel: 'Abbrechen',
    ok: 'OK',
    yes: 'Ja',
    no: 'Nein',
    search: 'Suchen',
    install: 'Installieren',
    uninstall: 'Deinstallieren',
    installed: 'Installiert'
  },
  
  '日本語': {
    bootTitle: 'AIdroid',
    bootSubtitle: 'OharaAIによって動作',
    selectLanguageTitle: '言語を選択',
    selectLanguageSubtitle: 'お好みの言語を選択してください',
    searchLanguages: '言語を検索...',
    pinSetupTitle: 'PIN設定',
    pinSetupSubtitle: '携帯電話を保護するための4桁のPINを作成してください',
    pinConfirmTitle: 'PIN確認',
    pinConfirmSubtitle: '確認のためにPINをもう一度入力してください',
    pinMismatchError: 'PINが一致しません。もう一度お試しください。',
    loadingMessages: [
      'AIdroidシステムを初期化中...',
      'アプリケーションを読み込み中...',
      'セキュリティを設定中...',
      'ネットワークを設定中...',
      'インターフェースを準備中...',
      'もうすぐ完了...',
      'AIdroidへようこそ!'
    ],
    welcomeTitle: 'AIdroidへようこそ!',
    languageLabel: '言語',
    settingsTitle: '設定',
    networkTitle: 'ネットワーク設定',
    networkSubtitle: 'ネットワーク接続を管理する',
    connectToNetwork: 'ネットワークに接続',
    connected: '接続済み',
    disconnected: '切断済み',
    selectNetwork: '接続するネットワークを選択',
    appNames: {
      whatsapp: 'WhatsApp',
      playstore: 'Play ストア',
      camera: 'カメラ',
      gallery: 'ギャラリー',
      settings: '設定',
      calendar: 'カレンダー',
      music: '音楽',
      maps: 'マップ',
      weather: '天気',
      calculator: '電卓',
      contacts: '連絡先',
      phone: '電話',
      browser: 'ブラウザ',
      clock: '時計',
      messages: 'メッセージ'
    },
    networkRequired: 'ネットワークが必要',
    noNetworkAccess: 'ネットワークアクセスなし',
    connectFirst: '最初にネットワークに接続してください',
    batteryDead: 'バッテリー切れ',
    batteryCharging: '充電中...',
    lowBattery: 'バッテリー残量少',
    calling: '通話中...',
    comingSoon: 'まもなく登場!',
    wantToGoBack: '戻りますか?',
    emergency: {
      police911: '警察 🚨',
      whatIsEmergency: '911 緊急事態は何ですか？',
      thisIsFakeCall: 'これは偽の通話です',
      emergencyEnded: '緊急通話終了'
    },
    autoResponses: [
      'こんにちは！メッセージありがとうございます！😊',
      '今忙しいですが、すぐにお返事します！',
      'メッセージありがとう！できるときにお返事します👍',
      'メッセージ受け取りました！また後で！💬',
       'こんにちは！できるだけ早くお返事します✨'
    ],
    whatsappMaintenance: {
      title: 'WhatsAppメンテナンス',
      message: '申し訳ございませんが、バグ修正のためWhatsAppは開発中です。連絡先をご利用ください。',
      useContacts: 'WhatsAppは2025年9月30日に復帰予定です',
      returnDate: '復帰予定：2025年9月30日',
      okButton: 'OK、連絡先を使用'
    },
    auth: {
      // Account creation
      createAccountTitle: 'アカウント作成',
      createAccountSubtitle: 'メールでAIdroidアカウントを設定',
      emailLabel: 'メールアドレス',
      emailPlaceholder: 'メールアドレスを入力',
      emailRequired: 'メールは必須です',
      emailInvalid: '有効なメールアドレスを入力してください',
      emailValid: 'メールが良さそうです！',
      continueButton: '続行',
      accountInfo: 'メールはPIN復旧に使用されます',
      termsInfo: '続行することで、AIdroidの利用規約に同意します',
      
      // PIN authentication
      welcomeBack: 'おかえりなさい',
      enterPin: '4桁のPINを入力してください',
      pinIncorrect: 'PINが間違っています',
      attemptsLeft: '回の試行が残っています',
      accountLocked: '試行回数が多すぎるためアカウントがロックされました',
      tryAgainIn: '再試行まで',
      authSuccess: '認証成功！',
      securityLock: 'セキュリティのためアカウントが一時的にロック',
      unlockIn: 'ロック解除まで',
      
      // PIN recovery
      forgotPin: '忘れた？',
      recoveryTitle: 'PIN復旧',
      recoverySubtitle: '{email}に復旧コードを送信します',
      sendCode: '復旧コードを送信',
      sending: '送信中...',
      codeSent: 'コード送信完了！',
      checkEmail: 'メールを確認してください：{email}',
      waitingForCode: 'システムがコードを送信するのを待っています...',
      enterCode: '復旧コードを入力',
      codeInstructions: 'メールの6桁のコードを入力してください',
      verifyCode: 'コード確認',
      codeInvalid: '6桁のコードを入力してください',
      codeIncorrect: '間違っているか期限切れのコード',
      recoveryFailed: '復旧に失敗しました。再試行してください。',
      recoveryError: '復旧中にエラーが発生しました',
      
      // PIN reset
      createNewPin: '新しいPIN作成',
      confirmNewPin: '新しいPIN確認',
      pinTooShort: 'PINは4桁である必要があります',
      pinMismatch: 'PINが一致しません',
      pinMatched: 'PINが一致しました！',
      resetPin: 'PINリセット',
      resetSuccess: 'PINリセット成功！',
      resetComplete: 'PINが更新されました',
      resetFailed: 'PINリセットに失敗しました',
      redirecting: 'ログインに転送中...'
    },
    back: '戻る',
    cancel: 'キャンセル',
    ok: 'OK',
    yes: 'はい',
    no: 'いいえ',
    search: '検索',
    install: 'インストール',
    uninstall: 'アンインストール',
    installed: 'インストール済み'
  },
  
  '한국어': {
    bootTitle: 'AIdroid',
    bootSubtitle: 'OharaAI로 구동됨',
    selectLanguageTitle: '언어 선택',
    selectLanguageSubtitle: '선호하는 언어를 선택하세요',
    searchLanguages: '언어 검색...',
    pinSetupTitle: 'PIN 설정',
    pinSetupSubtitle: '휴대폰을 보호하기 위한 4자리 PIN을 만드세요',
    pinConfirmTitle: 'PIN 확인',
    pinConfirmSubtitle: '확인을 위해 PIN을 다시 입력하세요',
    pinMismatchError: 'PIN이 일치하지 않습니다. 다시 시도해주세요.',
    loadingMessages: [
      'AIdroid 시스템 초기화 중...',
      '애플리케이션 로딩 중...',
      '보안 설정 중...',
      '네트워크 구성 중...',
      '인터페이스 준비 중...',
      '거의 완료...',
      'AIdroid에 오신 것을 환영합니다!'
    ],
    welcomeTitle: 'AIdroid에 오신 것을 환영합니다!',
    languageLabel: '언어',
    settingsTitle: '설정',
    networkTitle: '네트워크 설정',
    networkSubtitle: '네트워크 연결을 관리하세요',
    connectToNetwork: '네트워크에 연결',
    connected: '연결됨',
    disconnected: '연결 해제됨',
    selectNetwork: '연결할 네트워크를 선택하세요',
    appNames: {
      whatsapp: 'WhatsApp',
      playstore: 'Play 스토어',
      camera: '카메라',
      gallery: '갤러리',
      settings: '설정',
      calendar: '달력',
      music: '음악',
      maps: '지도',
      weather: '날씨',
      calculator: '계산기',
      contacts: '연락처',
      phone: '전화',
      browser: '브라우저',
      clock: '시계',
      messages: '메시지'
    },
    networkRequired: '네트워크 필요',
    noNetworkAccess: '네트워크 액세스 없음',
    connectFirst: '먼저 네트워크에 연결하세요',
    batteryDead: '배터리 소진',
    batteryCharging: '충전 중...',
    lowBattery: '배터리 부족',
    calling: '통화 중...',
    comingSoon: '곧 출시!',
    wantToGoBack: '돌아가시겠습니까?',
    emergency: {
      police911: '경찰 🚨',
      whatIsEmergency: '911 응급상황이 무엇인가요?',
      thisIsFakeCall: '이것은 가짜 전화입니다',
      emergencyEnded: '응급 통화 종료'
    },
    autoResponses: [
      '안녕하세요! 메시지 감사합니다! 😊',
      '지금 바쁘지만 곧 답변드리겠습니다!',
      '메시지 감사해요! 가능할 때 답변드릴게요 👍',
      '메시지 받았어요! 나중에 이야기해요! 💬',
      '안녕하세요! 최대한 빨리 답변드리겠습니다 ✨'
    ],
    whatsappMaintenance: {
      title: 'WhatsApp 유지보수',
      message: '죄송합니다. 버그 수정으로 인해 WhatsApp이 개발 중입니다. 연락처를 사용해주세요.',
      useContacts: 'WhatsApp은 2025년 9월 30일에 돌아올 예정입니다',
      returnDate: '예상 복귀: 2025년 9월 30일',
      okButton: 'OK, 연락처 사용'
    },
    auth: {
      // Account creation
      createAccountTitle: '계정 생성',
      createAccountSubtitle: '이메일로 AIdroid 계정을 설정하세요',
      emailLabel: '이메일 주소',
      emailPlaceholder: '이메일을 입력하세요',
      emailRequired: '이메일이 필요합니다',
      emailInvalid: '유효한 이메일 주소를 입력해주세요',
      emailValid: '이메일이 좋아 보입니다!',
      continueButton: '계속',
      accountInfo: '이메일은 PIN 복구에 사용됩니다',
      termsInfo: '계속하면 AIdroid 약관에 동의하는 것입니다',
      
      // PIN authentication
      welcomeBack: '돌아오신 것을 환영합니다',
      enterPin: '4자리 PIN을 입력하세요',
      pinIncorrect: '잘못된 PIN',
      attemptsLeft: '시도 횟수 남음',
      accountLocked: '너무 많은 시도로 인해 계정이 잠겼습니다',
      tryAgainIn: '다시 시도까지',
      authSuccess: '인증 성공!',
      securityLock: '보안을 위해 계정이 일시적으로 잠김',
      unlockIn: '잠금 해제까지',
      
      // PIN recovery
      forgotPin: '잊었나요?',
      recoveryTitle: 'PIN 복구',
      recoverySubtitle: '{email}로 복구 코드를 보내드리겠습니다',
      sendCode: '복구 코드 전송',
      sending: '전송 중...',
      codeSent: '코드 전송됨!',
      checkEmail: '이메일을 확인하세요: {email}',
      waitingForCode: '시스템에서 코드를 전송하기를 기다리는 중...',
      enterCode: '복구 코드 입력',
      codeInstructions: '이메일의 6자리 코드를 입력하세요',
      verifyCode: '코드 확인',
      codeInvalid: '6자리 코드를 입력해주세요',
      codeIncorrect: '잘못되거나 만료된 코드',
      recoveryFailed: '복구 실패. 다시 시도해주세요.',
      recoveryError: '복구 중 오류가 발생했습니다',
      
      // PIN reset
      createNewPin: '새 PIN 생성',
      confirmNewPin: '새 PIN 확인',
      pinTooShort: 'PIN은 4자리여야 합니다',
      pinMismatch: 'PIN이 일치하지 않습니다',
      pinMatched: 'PIN이 일치합니다!',
      resetPin: 'PIN 재설정',
      resetSuccess: 'PIN 재설정 성공!',
      resetComplete: 'PIN이 업데이트되었습니다',
      resetFailed: 'PIN 재설정 실패',
      redirecting: '로그인으로 리디렉션 중...'
    },
    back: '뒤로',
    cancel: '취소',
    ok: '확인',
    yes: '예',
    no: '아니오',
    search: '검색',
    install: '설치',
    uninstall: '제거',
    installed: '설치됨'
  },
  
  '中文': {
    bootTitle: 'AIdroid',
    bootSubtitle: '由 OharaAI 提供支持',
    selectLanguageTitle: '选择语言',
    selectLanguageSubtitle: '选择您的首选语言',
    searchLanguages: '搜索语言...',
    pinSetupTitle: '设置PIN',
    pinSetupSubtitle: '创建4位PIN码来保护您的手机',
    pinConfirmTitle: '确认PIN',
    pinConfirmSubtitle: '再次输入您的PIN码以确认',
    pinMismatchError: 'PIN码不匹配。请重试。',
    loadingMessages: [
      '正在初始化AIdroid系统...',
      '正在加载应用程序...',
      '正在设置安全性...',
      '正在配置网络...',
      '正在准备界面...',
      '即将完成...',
      '欢迎使用AIdroid!'
    ],
    welcomeTitle: '欢迎使用AIdroid!',
    languageLabel: '语言',
    settingsTitle: '设置',
    networkTitle: '网络设置',
    networkSubtitle: '管理您的网络连接',
    connectToNetwork: '连接到网络',
    connected: '已连接',
    disconnected: '已断开',
    selectNetwork: '选择要连接的网络',
    appNames: {
      whatsapp: 'WhatsApp',
      playstore: 'Play商店',
      camera: '相机',
      gallery: '图库',
      settings: '设置',
      calendar: '日历',
      music: '音乐',
      maps: '地图',
      weather: '天气',
      calculator: '计算器',
      contacts: '联系人',
      phone: '电话',
      browser: '浏览器',
      clock: '时钟',
      messages: '消息'
    },
    networkRequired: '需要网络',
    noNetworkAccess: '无网络访问',
    connectFirst: '请先连接到网络',
    batteryDead: '电池耗尽',
    batteryCharging: '充电中...',
    lowBattery: '电量不足',
    calling: '通话中...',
    comingSoon: '即将推出!',
    wantToGoBack: '要返回吗?',
    emergency: {
      police911: '警察 🚨',
      whatIsEmergency: '911 您的紧急情况是什么？',
      thisIsFakeCall: '这是虚假电话',
      emergencyEnded: '紧急通话已结束'
    },
    autoResponses: [
      '你好！谢谢你的消息！😊',
      '我现在很忙，但很快会回复你！',
      '谢谢你的消息！我会尽快回复👍',
      '收到你的消息了！稍后聊！💬',
      '你好！我会尽快回复✨'
    ],
    whatsappMaintenance: {
      title: 'WhatsApp维护中',
      message: '抱歉，由于修复错误，WhatsApp正在开发中。您可以使用联系人。',
      useContacts: 'WhatsApp将在2025年9月30日回归',
      returnDate: '预期回归：2025年9月30日',
      okButton: '好的，使用联系人'
    },
    auth: {
      // Account creation
      createAccountTitle: '创建账户',
      createAccountSubtitle: '使用邮箱设置您的AIdroid账户',
      emailLabel: '邮箱地址',
      emailPlaceholder: '输入您的邮箱',
      emailRequired: '邮箱是必需的',
      emailInvalid: '请输入有效的邮箱地址',
      emailValid: '邮箱看起来不错！',
      continueButton: '继续',
      accountInfo: '您的邮箱将用于PIN恢复',
      termsInfo: '继续即表示您同意AIdroid条款',
      
      // PIN authentication
      welcomeBack: '欢迎回来',
      enterPin: '输入您的4位PIN码',
      pinIncorrect: '错误的PIN码',
      attemptsLeft: '次尝试机会剩余',
      accountLocked: '由于尝试次数过多，账户已锁定',
      tryAgainIn: '重试时间',
      authSuccess: '认证成功！',
      securityLock: '出于安全考虑，账户暂时锁定',
      unlockIn: '解锁时间',
      
      // PIN recovery
      forgotPin: '忘记了？',
      recoveryTitle: '恢复PIN码',
      recoverySubtitle: '我们将向{email}发送恢复代码',
      sendCode: '发送恢复代码',
      sending: '发送中...',
      codeSent: '代码已发送！',
      checkEmail: '请检查您的邮箱：{email}',
      waitingForCode: '等待系统发送代码...',
      enterCode: '输入恢复代码',
      codeInstructions: '输入邮箱中的6位数字代码',
      verifyCode: '验证代码',
      codeInvalid: '请输入6位数字代码',
      codeIncorrect: '代码错误或已过期',
      recoveryFailed: '恢复失败。请重试。',
      recoveryError: '恢复过程中发生错误',
      
      // PIN reset
      createNewPin: '创建新PIN码',
      confirmNewPin: '确认新PIN码',
      pinTooShort: 'PIN码必须是4位数字',
      pinMismatch: 'PIN码不匹配',
      pinMatched: 'PIN码匹配！',
      resetPin: '重置PIN码',
      resetSuccess: 'PIN码重置成功！',
      resetComplete: '您的PIN码已更新',
      resetFailed: 'PIN码重置失败',
      redirecting: '正在重定向到登录...'
    },
    back: '返回',
    cancel: '取消',
    ok: '确定',
    yes: '是',
    no: '否',
    search: '搜索',
    install: '安装',
    uninstall: '卸载',
    installed: '已安装'
  }
}

export const getTranslation = (language: string): TranslationKey => {
  return translations[language] || translations['English']
}