'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface UserAccount {
  id: string
  email: string
  pin: string
  language: string
  createdAt: number
  lastLogin: number
  recoveryCode?: string
  recoveryCodeExpiry?: number
}

export interface AuthState {
  // Account management
  currentUser: UserAccount | null
  accounts: UserAccount[]
  isAuthenticated: boolean
  
  // Recovery system
  isRecoveryMode: boolean
  recoveryEmail: string
  recoveryCode: string
  recoveryExpiry: number
  
  // Actions
  createAccount: (email: string, pin: string, language: string) => string
  authenticateUser: (email: string, pin: string) => boolean
  logout: () => void
  deleteAccount: (accountId: string) => void
  
  // PIN Recovery
  initiateRecovery: (email: string) => boolean
  verifyRecoveryCode: (email: string, code: string) => boolean
  resetPin: (email: string, newPin: string) => boolean
  
  // Utilities
  getUserByEmail: (email: string) => UserAccount | null
  isEmailRegistered: (email: string) => boolean
  updateLastLogin: (accountId: string) => void
}

// Simulate sending email (in real app, this would be an API call)
const simulateEmailSend = (email: string, code: string): Promise<boolean> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log(`📧 Recovery email sent to ${email}: Your PIN recovery code is: ${code}`)
      resolve(true)
    }, 1000)
  })
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      accounts: [],
      isAuthenticated: false,
      isRecoveryMode: false,
      recoveryEmail: '',
      recoveryCode: '',
      recoveryExpiry: 0,

      createAccount: (email: string, pin: string, language: string): string => {
        const existingUser = get().getUserByEmail(email)
        if (existingUser) {
          throw new Error('Account already exists')
        }

        const newAccount: UserAccount = {
          id: `user_${Date.now()}`,
          email,
          pin,
          language,
          createdAt: Date.now(),
          lastLogin: Date.now()
        }

        set((state) => ({
          accounts: [...state.accounts, newAccount],
          currentUser: newAccount,
          isAuthenticated: true
        }))

        return newAccount.id
      },

      authenticateUser: (email: string, pin: string): boolean => {
        const user = get().getUserByEmail(email)
        if (user && user.pin === pin) {
          set({
            currentUser: user,
            isAuthenticated: true
          })
          get().updateLastLogin(user.id)
          return true
        }
        return false
      },

      logout: () => {
        set({
          currentUser: null,
          isAuthenticated: false,
          isRecoveryMode: false,
          recoveryEmail: '',
          recoveryCode: '',
          recoveryExpiry: 0
        })
      },

      deleteAccount: (accountId: string) => {
        set((state) => ({
          accounts: state.accounts.filter(acc => acc.id !== accountId),
          currentUser: state.currentUser?.id === accountId ? null : state.currentUser,
          isAuthenticated: state.currentUser?.id === accountId ? false : state.isAuthenticated
        }))
      },

      initiateRecovery: async (email: string): Promise<boolean> => {
        const user = get().getUserByEmail(email)
        if (!user) {
          return false
        }

        // Generate 6-digit recovery code
        const code = Math.floor(100000 + Math.random() * 900000).toString()
        const expiry = Date.now() + (5 * 60 * 1000) // 5 minutes from now

        set({
          isRecoveryMode: true,
          recoveryEmail: email,
          recoveryCode: code,
          recoveryExpiry: expiry
        })

        // Update user account with recovery info
        set((state) => ({
          accounts: state.accounts.map(acc => 
            acc.email === email 
              ? { ...acc, recoveryCode: code, recoveryCodeExpiry: expiry }
              : acc
          )
        }))

        // Simulate sending email
        await simulateEmailSend(email, code)
        return true
      },

      verifyRecoveryCode: (email: string, code: string): boolean => {
        const user = get().getUserByEmail(email)
        const now = Date.now()
        
        if (!user || !user.recoveryCode || !user.recoveryCodeExpiry) {
          return false
        }

        if (user.recoveryCodeExpiry < now) {
          // Code expired
          return false
        }

        return user.recoveryCode === code
      },

      resetPin: (email: string, newPin: string): boolean => {
        const user = get().getUserByEmail(email)
        if (!user) {
          return false
        }

        set((state) => ({
          accounts: state.accounts.map(acc => 
            acc.email === email 
              ? { ...acc, pin: newPin, recoveryCode: undefined, recoveryCodeExpiry: undefined }
              : acc
          ),
          isRecoveryMode: false,
          recoveryEmail: '',
          recoveryCode: '',
          recoveryExpiry: 0
        }))

        return true
      },

      getUserByEmail: (email: string): UserAccount | null => {
        return get().accounts.find(acc => acc.email === email) || null
      },

      isEmailRegistered: (email: string): boolean => {
        return get().accounts.some(acc => acc.email === email)
      },

      updateLastLogin: (accountId: string) => {
        set((state) => ({
          accounts: state.accounts.map(acc => 
            acc.id === accountId 
              ? { ...acc, lastLogin: Date.now() }
              : acc
          )
        }))
      }
    }),
    {
      name: 'aidroid-auth',
      getStorage: () => (typeof window !== 'undefined' ? localStorage : undefined)
    }
  )
)